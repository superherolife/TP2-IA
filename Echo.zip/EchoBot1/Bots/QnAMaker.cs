﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.12.2
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Schema;
using System;
using System.Threading.Tasks;

namespace EchoBot1.Bots
{
    public class QnAMaker
    {
        private QnAMakerEndpoint endpoint;

        public QnAMaker(QnAMakerEndpoint endpoint)
        {
            this.endpoint = endpoint;
        }

        internal Task GetAnswersAsync(ITurnContext<IMessageActivity> turnContext)
        {
            throw new NotImplementedException();
        }
    }
}